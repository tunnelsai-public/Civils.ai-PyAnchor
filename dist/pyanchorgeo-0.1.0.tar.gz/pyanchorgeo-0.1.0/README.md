# PyAnchor
A python package for soil anchor design using the Bustamante &amp; Doix (1985) method
This is an example